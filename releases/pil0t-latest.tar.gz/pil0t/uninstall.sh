#!/bin/bash
# PiL0t Uninstaller
# Run via: sudo purge-pil0t  OR  sudo purge-pilot  OR  sudo bash uninstall.sh

GREEN='\033[0;32m'; RED='\033[0;31m'; AMBER='\033[0;33m'
BOLD='\033[1m'; DIM='\033[2m'; CYAN='\033[0;36m'; NC='\033[0m'

clear
echo -e "${RED}"
cat << 'BANNER'
  ____  _ _     ___  _
 |  _ \(_) |   / _ \| |_
 | |_) | | |  | | | | __|
 |  __/| | |__| |_| | |_
 |_|   |_|_____\___/ \__|

BANNER
echo -e "${NC}${BOLD}${RED}  UNINSTALLER${NC}"
echo ""

# Must be root
if [ "$EUID" -ne 0 ]; then
    echo -e "  ${RED}Run with sudo: sudo purge-pil0t${NC}"
    exit 1
fi

# Non-interactive mode when called from the web UI
if [ "${PURGESCRIPT_NONINTERACTIVE:-}" != "1" ]; then

    echo -e "  ${BOLD}This script will perform the following actions:${NC}"
    echo ""
    echo -e "  ${RED}WILL BE REMOVED:${NC}"
    echo -e "  ${DIM}·${NC} pil0t-web systemd service (stopped, disabled, deleted)"
    echo -e "  ${DIM}·${NC} pil0t-tracker systemd service (stopped, disabled, deleted)"
    echo -e "  ${DIM}·${NC} /etc/pil0t/app.py — Flask web application"
    echo -e "  ${DIM}·${NC} /etc/pil0t/print_sku.py — USB keypad listener"
    echo -e "  ${DIM}·${NC} /etc/pil0t/uninstall.sh — this script"
    echo -e "  ${DIM}·${NC} /etc/pil0t/version.txt — version file"
    echo -e "  ${DIM}·${NC} /etc/pil0t/static/ — all frontend HTML files"
    echo -e "  ${DIM}·${NC} /etc/sudoers.d/pil0t — sudoers permissions entry"
    echo -e "  ${DIM}·${NC} /etc/network/if-up.d/pil0t-network — boot network script"
    echo -e "  ${DIM}·${NC} /usr/local/bin/purge-pil0t — uninstall command"
    echo -e "  ${DIM}·${NC} /usr/local/bin/purge-pilot — uninstall command (alternate spelling)"
    echo ""
    echo -e "  ${GREEN}WILL BE KEPT:${NC}"
    echo -e "  ${DIM}·${NC} /etc/pil0t/data/ — all your config and print history"
    echo -e "  ${DIM}·${NC} /etc/wpa_supplicant/wpa_supplicant.conf — WiFi profiles"
    echo -e "  ${DIM}·${NC} All installed system packages (flask, evdev, etc.)"
    echo ""
    echo -e "  ${AMBER}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "  ${BOLD}${AMBER}  CONFIRMATION REQUIRED${NC}"
    echo -e "  ${AMBER}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo -e "  Press the ${BOLD}Delete key 3 times${NC} to confirm."
    echo -e "  ${DIM}You will see DEL appear on screen each time.${NC}"
    echo ""

    DEL_COUNT=0
    printf "  "
    while [ $DEL_COUNT -lt 3 ]; do
        # Read first byte
        IFS= read -r -s -n1 key
        # Backspace / old delete (single byte)
        if [ "$key" = $'\x7f' ] || [ "$key" = $'\x08' ]; then
            DEL_COUNT=$((DEL_COUNT + 1))
            printf "${RED}DEL${NC} "
        # Escape sequence — read remainder (Delete key sends \e[3~)
        elif [ "$key" = $'\x1b' ]; then
            IFS= read -r -s -n1 -t 0.1 key2
            IFS= read -r -s -n1 -t 0.1 key3
            IFS= read -r -s -n1 -t 0.1 key4
            seq="${key2}${key3}${key4}"
            if [ "$seq" = "[3~" ] || [ "$seq" = "[3" ]; then
                DEL_COUNT=$((DEL_COUNT + 1))
                printf "${RED}DEL${NC} "
            fi
        fi
    done

    echo ""
    echo ""
    echo -e "  ${BOLD}Are you absolutely sure?${NC}"
    echo -e "  ${DIM}Press Enter to proceed or Ctrl+C to cancel.${NC}"
    echo ""
    read -r

    echo ""
    echo -e "  ${BOLD}${RED}Starting uninstall...${NC}"
    echo ""
fi

# ── Removal ───────────────────────────────────────────────────────────────────
removing() { echo -e "  ${RED}✕ Removing:${NC} $1"; }
done_()    { echo -e "  ${RED}  Gone.${NC}"; }

removing "pil0t-web service — stopping and disabling"
systemctl stop pil0t-web 2>/dev/null || true
systemctl disable pil0t-web 2>/dev/null || true
rm -f /etc/systemd/system/pil0t-web.service
done_

removing "pil0t-tracker service — stopping and disabling"
systemctl stop pil0t-tracker 2>/dev/null || true
systemctl disable pil0t-tracker 2>/dev/null || true
rm -f /etc/systemd/system/pil0t-tracker.service
done_

systemctl daemon-reload 2>/dev/null || true

removing "app.py — Flask web application"
rm -f /etc/pil0t/app.py; done_

removing "print_sku.py — USB keypad listener"
rm -f /etc/pil0t/print_sku.py; done_

removing "version.txt — installed version record"
rm -f /etc/pil0t/version.txt; done_

removing "static/ — all frontend HTML files"
rm -rf /etc/pil0t/static/; done_

removing "uninstall.sh — this script"
rm -f /etc/pil0t/uninstall.sh; done_

removing "sudoers entry — /etc/sudoers.d/pil0t"
rm -f /etc/sudoers.d/pil0t; done_

removing "network boot script — /etc/network/if-up.d/pil0t-network"
rm -f /etc/network/if-up.d/pil0t-network; done_

removing "purge-pil0t — registered uninstall command"
rm -f /usr/local/bin/purge-pil0t; done_

removing "purge-pilot — alternate uninstall command"
rm -f /usr/local/bin/purge-pilot; done_

echo ""

# ── Final verification ────────────────────────────────────────────────────────
echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BOLD}${CYAN}  FINAL VERIFICATION${NC}"
echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

FAIL=0

removed_ok() {
    local label="$1" path="$2"
    if [ ! -e "$path" ]; then
        echo -e "  ${GREEN}✓${NC} ${RED}$label${NC}"
    else
        echo -e "  ${RED}✗ STILL EXISTS: $label${NC}"
        FAIL=$((FAIL+1))
    fi
}

svc_removed() {
    local label="$1" svc="$2"
    if ! systemctl is-enabled "$svc" 2>/dev/null | grep -q "^enabled"; then
        echo -e "  ${GREEN}✓${NC} ${RED}$label${NC}"
    else
        echo -e "  ${RED}✗ STILL ENABLED: $label${NC}"
        FAIL=$((FAIL+1))
    fi
}

svc_removed   "pil0t-web service disabled"            "pil0t-web"
svc_removed   "pil0t-tracker service disabled"         "pil0t-tracker"
removed_ok    "pil0t-web.service file deleted"         "/etc/systemd/system/pil0t-web.service"
removed_ok    "pil0t-tracker.service file deleted"     "/etc/systemd/system/pil0t-tracker.service"
removed_ok    "app.py deleted"                         "/etc/pil0t/app.py"
removed_ok    "print_sku.py deleted"                   "/etc/pil0t/print_sku.py"
removed_ok    "version.txt deleted"                    "/etc/pil0t/version.txt"
removed_ok    "static/ directory deleted"              "/etc/pil0t/static"
removed_ok    "sudoers entry deleted"                  "/etc/sudoers.d/pil0t"
removed_ok    "network boot script deleted"            "/etc/network/if-up.d/pil0t-network"
removed_ok    "purge-pil0t command deleted"            "/usr/local/bin/purge-pil0t"
removed_ok    "purge-pilot command deleted"            "/usr/local/bin/purge-pilot"

echo ""
echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

if [ $FAIL -eq 0 ]; then
    echo -e "${BOLD}${GREEN}  ALL CLEAR — PiL0t fully removed.${NC}"
else
    echo -e "${BOLD}${AMBER}  $FAIL item(s) could not be removed — check above.${NC}"
fi

echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "  ${DIM}Data preserved at:   /etc/pil0t/data/${NC}"
echo -e "  ${DIM}To remove data too:  sudo rm -rf /etc/pil0t${NC}"
echo -e "  ${DIM}To reinstall:        curl -L https://bit.ly/4dbLv6M | sudo bash${NC}"
echo ""
