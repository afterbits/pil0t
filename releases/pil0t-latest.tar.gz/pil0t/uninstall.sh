#!/bin/bash
# PiL0t Uninstaller
# Run via: sudo purge-pil0t  OR  sudo purge-pilot  OR  sudo bash uninstall.sh

GREEN='\033[0;32m'; RED='\033[0;31m'; AMBER='\033[0;33m'; BOLD='\033[1m'; DIM='\033[2m'; NC='\033[0m'

clear
echo -e "${RED}"
cat << 'BANNER'
  ____  _ _     ___  _
 |  _ \(_) |   / _ \| |_
 | |_) | | |  | | | | __|
 |  __/| | |__| |_| | |_
 |_|   |_|_____\___/ \__|

BANNER
echo -e "${NC}${BOLD}${RED}  UNINSTALLER${NC}"
echo -e "${DIM}  This will remove PiL0t from this system.${NC}"
echo -e "${DIM}  Your data files will be preserved in /etc/pil0t/data/${NC}"
echo ""

# Must be root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}Run with sudo: sudo purge-pil0t${NC}"
    exit 1
fi

# Confirmation — skipped when called from web UI
if [ "${PURGESCRIPT_NONINTERACTIVE:-}" != "1" ]; then
    echo -e "${AMBER}Type the word ${BOLD}purge${NC}${AMBER} and press Enter to continue, or Ctrl+C to cancel:${NC}"
    echo ""
    read -r CONFIRM
    if [ "$CONFIRM" != "purge" ]; then
        echo -e "${DIM}Cancelled.${NC}"
        exit 0
    fi
fi

echo ""
echo -e "${BOLD}${RED}Removing PiL0t...${NC}"
echo ""

ok()   { echo -e "  ${GREEN}✓${NC} $1"; }
info() { echo -e "  ${DIM}· $1${NC}"; }

# Stop and disable services
info "Stopping services..."
systemctl stop pil0t-web 2>/dev/null && ok "pil0t-web stopped" || true
systemctl stop pil0t-tracker 2>/dev/null && ok "pil0t-tracker stopped" || true
systemctl disable pil0t-web 2>/dev/null || true
systemctl disable pil0t-tracker 2>/dev/null || true

# Remove service files
info "Removing service files..."
rm -f /etc/systemd/system/pil0t-web.service
rm -f /etc/systemd/system/pil0t-tracker.service
systemctl daemon-reload
ok "Service files removed"

# Remove application files (not data)
info "Removing application files..."
rm -f /etc/pil0t/app.py
rm -f /etc/pil0t/print_sku.py
rm -f /etc/pil0t/version.txt
rm -rf /etc/pil0t/static/
ok "Application files removed"

# Remove sudoers
rm -f /etc/sudoers.d/pil0t
ok "Sudoers entry removed"

# Remove boot network script
rm -f /etc/network/if-up.d/pil0t-network
ok "Network boot script removed"

# Remove the purge commands themselves
rm -f /usr/local/bin/purge-pil0t
rm -f /usr/local/bin/purge-pilot
ok "purge-pil0t and purge-pilot commands removed"

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BOLD}${GREEN}  PiL0t has been removed.${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "  ${DIM}Your data is preserved at: /etc/pil0t/data/${NC}"
echo -e "  ${DIM}To remove data too: sudo rm -rf /etc/pil0t${NC}"
echo -e "  ${DIM}To reinstall: curl -L https://bit.ly/4dbLv6M | tar -xz -C /tmp && sudo bash /tmp/pil0t/install.sh${NC}"
echo ""
